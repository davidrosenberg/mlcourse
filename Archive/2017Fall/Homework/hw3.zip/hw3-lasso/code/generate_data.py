"""
Generating training, test, validation splits for the Lasso homework.

Author: David Rosenberg <david.davidr@gmail.com>
License: Creative Commons Attribution 4.0 International License
"""

from sklearn.model_selection import train_test_split
import random
import numpy as np
import matplotlib.pyplot as plt
import pickle

def stepFnGenerator(stepLoc=0):
    def f(x):
        ret = np.zeros(len(x))
        ret[x >= stepLoc] = 1
        return ret
    return f

def linearCombGenerator(fns, coefs):
    def f(x):
        return sum(fns[i](x) * coefs[i] for i in range(len(fns)))
    return f

def get_data(n=1000, num_basis_fns = 100, num_nonzero = 10, noise_SD=.25):
    # We'll construct a function as a linear combination of step "basis"
    # functions. We'll then apply it randomly chosen points from interval [0,1]
    # to create data. We'll featurize the points from the input space [0,1]
    # using our basis functions.

    # Construct basis, to be used for generating target function and features
    all_basis_fns = [stepFnGenerator(stepLoc=s)
                     for s in np.linspace(0, 1, num_basis_fns, endpoint=False)]

    # Construct target function (the Bayes prediction function)
    nonzero_indices = np.random.choice(num_basis_fns, num_nonzero)
    coefs = np.zeros(num_basis_fns)
    coefs[nonzero_indices] = np.random.randn(num_nonzero)
    target_fn = linearCombGenerator(all_basis_fns, coefs)

    # Construct dataset
    x = np.sort(np.random.rand(n))
    y_target = target_fn(x)
    y_observed = y_target + noise_SD * np.random.randn(n)

    # Featurize input values in []0,1]
    X_ftrs = np.empty((n, num_basis_fns))
    for ftr_num in range(num_basis_fns):
        X_ftrs[:, ftr_num] = all_basis_fns[ftr_num](x)

    return x, X_ftrs, y_observed, target_fn

def get_data_splits(n=1000, num_basis_fns=100, num_nonzero=10,
                    noise_SD=.25, test_frac=.2):

    x, X_ftrs, y_observed, target_fn = get_data(n, num_basis_fns,
                                                num_nonzero, noise_SD)
    X_train, X_test, y_train, y_test = train_test_split(X_ftrs, y_observed,
                                                        test_size=test_frac,
                                                        random_state=1)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train,
                                                      test_size=0.2,
                                                      random_state=1)
    return X_train, y_train, X_val, y_val, X_test, y_test


def main():
    # Generate data and write it to disk
    X_train, y_train, X_val, y_val, X_test, y_test = get_data_splits()
    np.savez_compressed('data.npz', X_train=X_train, y_train=y_train,
                        X_val=X_val, y_val=y_val, X_test=X_test, y_test=y_test)

    # Demonstrate loading data back
    data = np.load('data.npz')
    X_train = data['X_train']
    X_val = data['X_val']
    y_train = data['y_train']
    y_val = data['y_val']
    X_test = data['X_test']
    y_test = data['y_test']

    # Let's plot the target function (i.e. the Bayes prediction function) as
    # well as some noisy observations, as a function of the original input
    # space, which is the interval [0,1]. The data actually returned in
    # X_train, etc. is a featurization of this input space using step
    # functions.  See code above.
    x, X_ftrs, y_observed, target_fn = get_data()
    y_Bayes = target_fn(x)
    ## Plot target function
    plt.scatter(x,y_observed, color='r')
    plt.plot(x,y_Bayes)
    plt.show()

if __name__ == '__main__':
  main()

