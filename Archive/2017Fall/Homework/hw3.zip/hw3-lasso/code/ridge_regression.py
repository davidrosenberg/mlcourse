"""
Ridge regression using scipy's minimize function and demonstrating the use of
sklearn's framework.

Author: David Rosenberg <david.davidr@gmail.com>
License: Creative Commons Attribution 4.0 International License
"""

from sklearn.base import BaseEstimator, RegressorMixin
from scipy.optimize import minimize
import numpy as np

class RidgeRegression(BaseEstimator, RegressorMixin):
    """ ridge regression"""

    def __init__(self, l2reg=1):
        if l2reg < 0:
            raise ValueError('Regularization penalty should be at least 0.')
        self.l2reg = l2reg

    def fit(self, X, y=None):
        n, num_ftrs = X.shape
        # convert to 1-dim array, in case we're given a column vector
        y = y.reshape(-1) 
        def ridge_obj(w):
            predictions = np.dot(X,w)
            residual = y - predictions
            empirical_risk = np.sum(residual**2)
            l2_norm_squared = np.sum(w**2)
            objective = empirical_risk + self.l2reg * l2_norm_squared
            return objective
        self.ridge_obj_ = ridge_obj

        w_0 = np.zeros(num_ftrs)
        self.w_ = minimize(ridge_obj, w_0).x
        return self

    def predict(self, X, y=None):
        try:
            getattr(self, "w_")
        except AttributeError:
            raise RuntimeError("You must train classifer before predicting data!")

        return np.dot(X, self.w_)


def main():

    # Get data
    load_data_from_file = True
    if load_data_from_file:
        data = np.load('data.npz')
        X_train = data['X_train']
        X_val = data['X_val']
        y_train = data['y_train']
        y_val = data['y_val']
        X_test = data['X_test']
        y_test = data['y_test']
    else:
        from generate_data import get_data_splits
        X_train, y_train, X_val, y_val, X_test, y_test = get_data_splits(n=1000, num_basis_fns=100, num_nonzero=10)

    # Compare our RidgeRegression to sklearn's.

    # First run sklearn ridge regression and extract the coefficients
    from sklearn.linear_model import Ridge
    l2_reg = 2
    # Fit with sklearn -- need to multiply l2_reg by sample size, since their
    # objective function is the total square loss, rather than average square
    # loss.
    n = X_train.shape[0]
    sklearn_ridge = Ridge(alpha=l2_reg, fit_intercept=False, normalize=False)
    sklearn_ridge.fit(X_train, y_train) 
    sklearn_ridge_coefs = sklearn_ridge.coef_

    # Now run our ridge regression and compare the coefficients to sklearn's
    ridge_regression_estimator = RidgeRegression(l2reg=l2_reg)
    ridge_regression_estimator.fit(X_train, y_train)
    our_coefs = ridge_regression_estimator.w_

    print "Hoping this is very close to 0: ", np.sum(
        (our_coefs - sklearn_ridge_coefs)**2 )

    # Now let's use sklearn to help us do hyperparameter searching
    from sklearn.model_selection import GridSearchCV,PredefinedSplit
    from sklearn.model_selection import ParameterGrid
    from sklearn.metrics import mean_squared_error, make_scorer
    import pandas as pd

    # grid.fit by default splits the data into training and
    # validation itself; we want to use our own splits, so we need to stack our
    # training and validation sets together, and supply an index
    # (validation_fold) to specify which entries are train and which are
    # validation.
    X_train_val = np.vstack((X_train, X_val))
    y_train_val = np.concatenate((y_train, y_val))
    val_fold = [-1]*len(X_train) + [0]*len(X_val) #0 corresponds to validation

    # Now we set up and do the grid search over l2reg the np.concatenate
    # command illustrates my search for the best hyperparameter. In each line,
    # I'm zooming in to a particular hyperparameter range that showed promise
    # in the previous grid. This approach works reasonably well when
    # performance is convex as a function of the hyperparameter, which it seems
    # to be here.
    param_grid = [{'l2reg':np.concatenate((10.**np.arange(-6,3,1),
                                           np.arange(2,10,2),
                                           np.arange(.23,2,.23),
                                           np.arange(1.08,1.38,.08),
                                           np.arange(1.181,1.3,.021)
                                             )) }]
    ridge_regression_estimator = RidgeRegression()
    grid = GridSearchCV(ridge_regression_estimator,
                        param_grid,
                        cv = PredefinedSplit(test_fold=val_fold),
                        scoring = make_scorer(mean_squared_error,
                                              greater_is_better = False))
    grid.fit(X_train_val, y_train_val) 

    #    pd.set_option('display.max_rows', 20)
    df = pd.DataFrame(grid.cv_results_)
    # Flip sign of score back, because GridSearchCV likes to maximize,
    # so it flips the sign of the score if "greater_is_better=FALSE"
    df['mean_test_score'] = -df['mean_test_score']
    df['mean_train_score'] = -df['mean_train_score']
    cols_to_keep = ["param_l2reg", "mean_test_score","mean_train_score"]
    df_toshow = df[cols_to_keep].fillna('-')
    df_toshow = df_toshow.sort_values(by=["param_l2reg"])
    print df_toshow

if __name__ == '__main__':
  main()
